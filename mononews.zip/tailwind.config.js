/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*/{htm,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}


